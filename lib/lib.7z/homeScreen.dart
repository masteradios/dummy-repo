// import 'dart:async';
// import 'dart:io';
// import 'dart:math';
// import 'package:animations/animations.dart';
// import 'package:bounce/bounce.dart';
// import 'package:http/http.dart' as http;
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/material.dart';
// import 'package:iconsax/iconsax.dart';
// import 'package:image_picker/image_picker.dart';
//
// import 'models/modelImage.dart';
//
// class ImageUploadScreen extends StatefulWidget {
//   @override
//   _ImageUploadScreenState createState() => _ImageUploadScreenState();
// }
//
// class _ImageUploadScreenState extends State<ImageUploadScreen> {
//   Timer? _messageTimer;
//   String _currentMessage = '';
//   final _random = Random();
//   final _processingMessages = const [
//     'Processing your image...',
//     'Hang tight!',
//     'Applying filters...',
//     'Optimizing quality...',
//     'Almost there...',
//     'Finalizing upload...',
//   ];
//
//   @override
//   void dispose() {
//     _messageTimer?.cancel();
//     super.dispose();
//   }
//
//   void _startMessageTimer() {
//     _currentMessage = _processingMessages[_random.nextInt(_processingMessages.length)];
//     _messageTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
//       if (!mounted) return;
//       setState(() {
//         _currentMessage = _processingMessages[_random.nextInt(_processingMessages.length)];
//       });
//     });
//   }
//
//   void _stopMessageTimer() {
//     _messageTimer?.cancel();
//     _messageTimer = null;
//   }
//   File? _image;
//   bool _isLoading = false;
//   String? _error;
//   final ImagePicker _picker = ImagePicker();
//   final FirebaseStorage _storage = FirebaseStorage.instance;
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//
//   Future<void> _pickImage(ImageSource source) async {
//     try {
//       final pickedFile = await _picker.pickImage(source: source);
//       if (pickedFile != null) {
//         setState(() {
//           _image = File(pickedFile.path);
//           _error = null;
//         });
//       }
//     } catch (e) {
//       setState(() => _error = 'Failed to pick image: ${e.toString()}');
//     }
//   }
//
//   Future<void> _uploadImage() async {
//     if (_image == null) return;
//
//     setState(() {
//       _isLoading = true;
//       _error = null;
//     });
//     _startMessageTimer();
//
//     try {
//       // Upload to Firebase Storage
//       final String downloadUrl = await _uploadImageToStorage(_image!);
//
//       // Save metadata to Firestore
//       await _saveImageMetadata(downloadUrl, _image!.path.split('/').last);
//
//       // Send to server
//       await _sendImageToServer(downloadUrl);
//
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Image uploaded successfully!')),
//       );
//     } catch (e) {
//       _stopMessageTimer();
//       setState(() => _error = 'Upload failed: ${e.toString()}');
//     } finally {
//       _stopMessageTimer();
//       setState(() => _isLoading = false);
//     }
//   }
//
//   Future<String> _uploadImageToStorage(File image) async {
//     final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
//     final Reference ref = _storage.ref().child('images/$fileName');
//     await ref.putFile(image);
//     return await ref.getDownloadURL();
//   }
//
//   Future<void> _saveImageMetadata(String url, String fileName) async {
//     final doc = _firestore.collection('images').doc();
//     final image = ModelImage(
//       id: doc.id,
//       url: url,
//       fileName: fileName,
//       timestamp: DateTime.now(),
//     );
//     await doc.set(image.toMap());
//   }
//
//   Future<void> _sendImageToServer(String imageUrl) async {
//     const String serverUrl = 'YOUR_SERVER_ENDPOINT';
//     final response = await http.post(
//       Uri.parse(serverUrl),
//       body: {'imageUrl': imageUrl},
//     );
//
//     if (response.statusCode != 200) {
//       throw Exception('Server error: ${response.body}');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Image Upload')),
//       body: Padding(
//         padding: const EdgeInsets.all(20.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.stretch,
//           children: [
//             if (_error != null)
//               Padding(
//                   padding: const EdgeInsets.only(bottom: 20),
//                   child: Text(_error!, style: TextStyle(color: Colors.red))),
//             Expanded(
//               child: _image == null
//                   ? _buildPlaceholder()
//                   : Image.file(_image!, fit: BoxFit.cover),
//             ),
//             SizedBox(height: 20),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//
//                 Bounce(
//
//                   scaleFactor: 1.2,
//                   onTap: () => _pickImage(ImageSource.gallery),
//                   child: Container(
//                     padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
//                     decoration: BoxDecoration(
//                       color: Colors.white, // Background color
//                       borderRadius: BorderRadius.circular(20),
//
//                     ),
//                     child: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(Iconsax.gallery, color: Colors.black),
//                         SizedBox(width: 8),
//                         Text('Gallery', style: TextStyle(color: Colors.black)),
//                       ],
//                     ),
//                   ),
//                 ),
//                 Bounce(
//                   scaleFactor: 1.2,
//                   onTap: () => _pickImage(ImageSource.camera),
//                   child: Container(
//                     padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
//                     decoration: BoxDecoration(
//                       color: Colors.white, // Background color
//                       borderRadius: BorderRadius.circular(20),
//
//                     ),
//                     child: Row(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         Icon(Iconsax.gallery, color: Colors.black),
//                         SizedBox(width: 8),
//                         Text('Camera', style: TextStyle(color: Colors.black)),
//                       ],
//                     ),
//                   ),
//                 )
//               ],
//             ),
//             SizedBox(height: 20),
//
//             if (_isLoading) ...[
//               const SizedBox(height: 20),
//               LinearProgressIndicator(
//                 backgroundColor: Colors.grey[200],
//                 valueColor: AlwaysStoppedAnimation<Color>(
//                   Colors.black45
//                 ),
//               ),
//               const SizedBox(height: 10),
//               AnimatedSwitcher(
//                 duration: const Duration(milliseconds: 500),
//                 child: Text(
//                   _currentMessage,
//                   key: ValueKey<String>(_currentMessage),
//                   style: TextStyle(
//                     color: Colors.grey[600],
//                     fontStyle: FontStyle.italic,
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 20),
//             ],
//
//             ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 padding: EdgeInsets.symmetric(vertical: 15),
//               ),
//               onPressed: _isLoading || _image == null ? null : _uploadImage,
//               child: _isLoading
//                   ? SizedBox(
//                 height: 20,
//                 width: 20,
//                 child: CircularProgressIndicator(strokeWidth: 2,color: Colors.black,),
//               )
//                   : Text('Upload Image',style: TextStyle(color: Colors.black),),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildBounceButton({
//     required String label,
//     IconData? icon,
//     VoidCallback? onPressed,
//     bool isUpload = false,
//   }) {
//     return Bounce(
//       duration: const Duration(milliseconds: 200),
//       child: ElevatedButton.icon(
//         icon: icon != null ? Icon(icon) : const SizedBox(),
//         label: Text(label),
//         style: ElevatedButton.styleFrom(
//           padding: EdgeInsets.symmetric(
//             vertical: 15,
//             horizontal: isUpload ? 30 : 20,
//           ),
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(25),
//           ),
//         ),
//         onPressed: onPressed,
//       ),
//     );
//   }
//
//   Widget _buildPlaceholder() {
//     return Container(
//         decoration: BoxDecoration(
//         color: Colors.grey[200],
//         borderRadius: BorderRadius.circular(10)),
//     child: Center(
//     child: Column(
//     mainAxisSize: MainAxisSize.min,
//     children: [
//     Icon(Icons.image, size: 50, color: Colors.grey[400]),
//     Text('No image selected', style: TextStyle(color: Colors.grey[500])),
//     ],
//     ),
//     ),
//     );
//   }
// }


import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:animations/animations.dart';
import 'package:bounce/bounce.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:image_picker/image_picker.dart';

import 'constants.dart';
import 'models/modelImage.dart';

class HumanUploadScreen extends StatefulWidget {
  @override
  _HumanUploadScreenState createState() => _HumanUploadScreenState();
}

class _HumanUploadScreenState extends State<HumanUploadScreen> {
  Timer? _messageTimer;
  String _currentMessage = '';
  final _random = Random();

  String? selectedBuild;
  String? selectedFit;

  final List<String> buildOptions = ['Slim', 'Regular', 'Athletic'];
  final List<String> fitOptions = ['Tight', 'Regular', 'Loose'];
  final _processingMessages = const [
    'Processing your image...',
    'Hang tight!',
    'Applying filters...',
    'Optimizing quality...',
    'Almost there...',
    'Finalizing upload...',
  ];

  // New state variable for toggling full body detection.
  // When true, full body detection is enabled (and we call the /detect/full API).
  // Otherwise, face detection is used (calling /detect/face).
  bool _enableFullBody = false;


  String calculateSize({
    required double weight,
    required double height,
    required String sex,
    bool unitSwitch = false,
  }) {
    // Convert units if necessary
    if (unitSwitch) {
      // Convert inches to cm
      height = height * 2.54;
    }

    // Validate weight and height
    if (weight <= 0 || height <= 0) {
      return 'Please enter valid weight and height.';
    }

    String? size;

    // Size calculation based on sex
    if (sex.toLowerCase() == 'male') {
      if (height < 165) {
        if (weight < 60) {
          size = 'S';
        } else if (weight < 75) {
          size = 'M';
        } else {
          size = 'L';
        }
      } else if (height < 180) {
        if (weight < 70) {
          size = 'M';
        } else if (weight < 90) {
          size = 'L';
        } else {
          size = 'XL';
        }
      } else {
        if (weight < 80) {
          size = 'L';
        } else if (weight < 100) {
          size = 'XL';
        } else if (weight < 120) {
          size = 'XXL';
        } else {
          size = 'XXXL';
        }
      }
    } else if (sex.toLowerCase() == 'female') {
      if (height < 155) {
        if (weight < 50) {
          size = 'XS';
        } else if (weight < 65) {
          size = 'S';
        } else {
          size = 'M';
        }
      } else if (height < 170) {
        if (weight < 60) {
          size = 'S';
        } else if (weight < 75) {
          size = 'M';
        } else {
          size = 'L';
        }
      } else {
        if (weight < 70) {
          size = 'M';
        } else if (weight < 85) {
          size = 'L';
        } else {
          size = 'XL';
        }
      }
    } else if (sex.toLowerCase() == 'youth') {
      if (height < 140) {
        size = 'Youth S';
      } else if (height < 160) {
        size = 'Youth M';
      } else {
        size = 'Youth L';
      }
    }

    // Adjust based on build type
    // if (build.toLowerCase() == 'athletic') {
    //   size = {
    //     'XS': 'S',
    //     'S': 'M',
    //     'M': 'L',
    //     'L': 'XL',
    //     'XL': 'XXL',
    //     'XXL': 'XXXL',
    //   }[size] ?? size;
    // }
    //
    //
    // if (fit.toLowerCase() == 'loose') {
    //   size = {
    //     'XS': 'S',
    //     'S': 'M',
    //     'M': 'L',
    //     'L': 'XL',
    //     'XL': 'XXL',
    //     'XXL': 'XXXL',
    //   }[size] ?? size;
    // }

    return size ?? 'Size not determined.';
  }




  @override
  void dispose() {
    _messageTimer?.cancel();
    super.dispose();
  }

  void _startMessageTimer() {
    _currentMessage = _processingMessages[_random.nextInt(_processingMessages.length)];
    _messageTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (!mounted) return;
      setState(() {
        _currentMessage = _processingMessages[_random.nextInt(_processingMessages.length)];
      });
    });
  }

  void _stopMessageTimer() {
    _messageTimer?.cancel();
    _messageTimer = null;
  }

  File? _image;
  bool _isLoading = false;
  String? _responseMessage;
  final ImagePicker _picker = ImagePicker();
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(source: source);
      if (pickedFile != null) {
        setState(() {
          _image = File(pickedFile.path);
          _responseMessage = null;
        });
      }
    } catch (e) {
      setState(() => _responseMessage = 'Failed to pick image: ${e.toString()}');
    }
  }

  Future<void> _uploadImage() async {
    if (_image == null) return;

    setState(() {
      _isLoading = true;
      _responseMessage = null;
    });
    _startMessageTimer();

    try {
      // Upload to Firebase Storage
      final String downloadUrl = await _uploadImageToStorage(_image!);

      // Save metadata to Firestore
      await _saveImageMetadata(downloadUrl, _image!.path.split('/').last);

      // Send to server
      await _sendImageToServer(downloadUrl);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Image uploaded successfully!')),
      );
    } catch (e) {
      _stopMessageTimer();
      setState(() => _responseMessage = 'Upload failed: ${e.toString()}');
    } finally {
      _stopMessageTimer();
      setState(() => _isLoading = false);
    }
  }

  Future<String> _uploadImageToStorage(File image) async {
    final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
    final Reference ref = _storage.ref().child('images/$fileName');
    await ref.putFile(image);
    return await ref.getDownloadURL();
  }

  Future<void> _saveImageMetadata(String url, String fileName) async {
    final doc = _firestore.collection('images').doc();
    final image = ModelImage(
      id: doc.id,
      url: url,
      fileName: fileName,
      timestamp: DateTime.now(),
    );
    await doc.set(image.toMap());
  }

  Future<void> _sendImageToServer(String imageUrl) async {
    // Choose the API endpoint based on the toggle state.
    // If full body detection is enabled, we call '/detect/full',
    // otherwise we use '/detect/face'.
    final String apiPath ='/detect/human';
    final String serverUrl = '$baseUrl$apiPath';

    final response = await http.post(
      Uri.parse(serverUrl),
      body: jsonEncode({'firebase_url': imageUrl}),
        headers: {
          'Content-Type':"application/json"
        }
    );

    if (response.statusCode != 200) {
      throw Exception('Server error: ${response.body}');
    }
    final data = json.decode(response.body);
    List<dynamic> predictions;
    String predictionType;

    if (_enableFullBody) {
      predictions = data['person_predictions'] as List;
      predictionType = "Person Predictions";
    } else {
      predictions = data['face_predictions'] as List;
      predictionType = "Face Predictions";
    }

    // Build a formatted response message with each prediction on a new line.
    String message = "$predictionType:\n";
    for (var pred in predictions) {
      int index = _enableFullBody ? pred['person_index'] : pred['face_index'];
      double height = pred['predicted_height'];
      double weight = pred['predicted_weight'];
      String size=calculateSize(weight: weight, height: height, sex: "sex");
      message += "\nPerson ${index+1}: \nHeight = ${height.toStringAsFixed(2)} m, \nWeight = ${weight.toStringAsFixed(2)} kg\n Size = $size";

    }

    setState(() {
      _responseMessage = message.trim();
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Human Detection')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: ListView(
          //crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_responseMessage != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Text(_responseMessage!, style: TextStyle(color: Colors.black,fontSize: 16)),
              ),
            Expanded(
              child: _image == null ? _buildPlaceholder() : Image.file(_image!, fit: BoxFit.contain),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Bounce(
                  scaleFactor: 1.2,
                  onTap: (_isLoading)?null:() => _pickImage(ImageSource.gallery),
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Iconsax.gallery, color: Colors.black),
                        SizedBox(width: 8),
                        Text('Gallery', style: TextStyle(color: Colors.black)),
                      ],
                    ),
                  ),
                ),
                Bounce(
                  scaleFactor: 1.2,
                  onTap: (_isLoading)?null:() => _pickImage(ImageSource.camera),
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Iconsax.gallery, color: Colors.black),
                        SizedBox(width: 8),
                        Text('Camera', style: TextStyle(color: Colors.black)),
                      ],
                    ),
                  ),
                )
              ],
            ),
            SizedBox(height: 20),

            // Custom toggle for full body detection.
            Center(child: _buildDetectionToggle()),
            SizedBox(height: 20),

            if (_isLoading) ...[
              const SizedBox(height: 20),
              LinearProgressIndicator(
                backgroundColor: Colors.grey[200],
                valueColor: AlwaysStoppedAnimation<Color>(Colors.black45),
              ),
              const SizedBox(height: 10),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 500),
                child: Text(
                  _currentMessage,
                  key: ValueKey<String>(_currentMessage),
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ] else ...[
              const SizedBox(height: 75,),
            ],


            ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 15),
              ),
              onPressed: _isLoading || _image == null ? null : _uploadImage,
              child: _isLoading
                  ? SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
              )
                  : Text('Upload Image', style: TextStyle(color: Colors.black)),
            ),
          ],
        ),
      ),
    );
  }

  // Custom toggle widget using Bounce for a fun animated effect.
  Widget _buildDetectionToggle() {
    return Bounce(
      scaleFactor: 1.1,
      duration: Duration(milliseconds: 200),
      onTap: (_isLoading)?null:() {
        setState(() {
          _enableFullBody = !_enableFullBody;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(25),
          boxShadow: [
            BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 4)),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _enableFullBody ? Icons.check_box : Icons.check_box_outline_blank,
              color: Colors.black,
            ),
            SizedBox(width: 10),
            Text(
              'Enable full body detection?',
              style: TextStyle(color: Colors.black),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.image, size: 50, color: Colors.grey[400]),
            Text('No image selected', style: TextStyle(color: Colors.grey[500])),
          ],
        ),
      ),
    );
  }
}
