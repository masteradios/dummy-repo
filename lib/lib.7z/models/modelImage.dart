import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;

class ModelImage {
  final String id;
  final String url;
  final String fileName;
  final DateTime timestamp;

  ModelImage({
    required this.id,
    required this.url,
    required this.fileName,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'url': url,
      'fileName': fileName,
      'timestamp': timestamp,
    };
  }

  static ModelImage fromMap(Map<String, dynamic> map) {
    return ModelImage(
      id: map['id'],
      url: map['url'],
      fileName: map['fileName'],
      timestamp: (map['timestamp'] as Timestamp).toDate(),
    );
  }
}
